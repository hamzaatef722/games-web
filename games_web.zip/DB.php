<?php
$host     = "sql113.infinityfree.com";
$dbname   = "if0_41783090_games_web";
$username = "if0_41783090";
$password = "hamzaatef1911";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>